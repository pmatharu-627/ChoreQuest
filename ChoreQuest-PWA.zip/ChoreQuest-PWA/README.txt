ChoreQuest PWA

Files:
- index.html
- styles.css
- app.js
- manifest.webmanifest
- service-worker.js

How to test on Windows:
1. Unzip the folder.
2. Open the folder in VS Code or any editor.
3. For full PWA install/offline behavior, serve it with a local web server.
   Example if Python is installed:
   python -m http.server 8000
4. Visit http://localhost:8000 on your computer.

How to use on Android:
- The easiest path is to upload these files to a simple host such as GitHub Pages, Netlify, Vercel, or Cloudflare Pages.
- Open the hosted URL in Chrome on Android.
- Tap the browser menu and choose "Add to Home screen" or "Install app".

Default parent PIN: 1234

This starter stores data locally in the browser on the device.
