
const defaultState = {
  childName: "Ava",
  pin: "1234",
  coins: 125,
  streak: 4,
  chores: [
    {id:1,title:"Make your bed",points:5,icon:"🛏️",done:false},
    {id:2,title:"Homework",points:15,icon:"📚",done:false},
    {id:3,title:"Clean your room",points:20,icon:"🧹",done:false},
    {id:4,title:"Read for 20 minutes",points:10,icon:"📖",done:false}
  ],
  rewards: [
    {id:1,title:"Movie Night",cost:200,emoji:"🎬"},
    {id:2,title:"Ice Cream",cost:100,emoji:"🍦"},
    {id:3,title:"30 Min Screen Time",cost:75,emoji:"🎮"},
    {id:4,title:"Choose Dinner",cost:150,emoji:"🍕"}
  ],
  activity: ["Welcome to ChoreQuest!"]
};

let state = JSON.parse(localStorage.getItem("chorequest-state") || "null") || defaultState;

const $ = s => document.querySelector(s);
function save(){ localStorage.setItem("chorequest-state", JSON.stringify(state)); render(); }
function toast(msg){
  const t=$("#toast"); t.textContent=msg; t.classList.add("show");
  setTimeout(()=>t.classList.remove("show"),1700);
}
function render(){
  $("#childName").textContent=state.childName;
  $("#coinBalance").textContent=state.coins;
  $("#streakCount").textContent=state.streak;

  const goal=state.rewards[0];
  $("#goalName").textContent=goal.title;
  $("#goalCurrent").textContent=Math.min(state.coins,goal.cost);
  $("#goalTarget").textContent=goal.cost;
  $("#progressBar").style.width=`${Math.min(100,state.coins/goal.cost*100)}%`;

  $("#choresList").innerHTML=state.chores.map(c=>`
    <div class="chore">
      <div class="chore-left">
        <div class="chore-icon">${c.icon || "✅"}</div>
        <div><div class="chore-title">${escapeHtml(c.title)}</div><div class="chore-points">+${c.points} coins</div></div>
      </div>
      <button class="done-btn" data-chore="${c.id}" ${c.done?"disabled":""}>${c.done?"Done ✓":"Done"}</button>
    </div>`).join("");

  $("#rewardsList").innerHTML=state.rewards.map(r=>`
    <div class="reward">
      <div class="emoji">${r.emoji}</div>
      <h3>${escapeHtml(r.title)}</h3>
      <p>🪙 ${r.cost} coins</p>
      <button class="redeem" data-reward="${r.id}" ${state.coins<r.cost?"disabled":""}>Redeem</button>
    </div>`).join("");

  $("#activityList").innerHTML=(state.activity||[]).slice(0,6).map(a=>`
    <div class="activity-item"><span>${escapeHtml(a)}</span><span>now</span></div>`).join("");
}
function escapeHtml(s){ return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[m])); }

document.addEventListener("click",e=>{
  const choreBtn=e.target.closest("[data-chore]");
  if(choreBtn){
    const id=Number(choreBtn.dataset.chore), c=state.chores.find(x=>x.id===id);
    if(c && !c.done){
      c.done=true; state.coins+=c.points; state.activity.unshift(`Completed "${c.title}" (+${c.points})`);
      save(); toast(`Great job! +${c.points} coins 🎉`);
    }
  }
  const rewardBtn=e.target.closest("[data-reward]");
  if(rewardBtn){
    const id=Number(rewardBtn.dataset.reward), r=state.rewards.find(x=>x.id===id);
    if(r && state.coins>=r.cost){
      state.coins-=r.cost; state.activity.unshift(`Redeemed "${r.title}" (-${r.cost})`);
      save(); toast(`${r.title} redeemed! 🎁`);
    }
  }
});

$("#parentBtn").onclick=()=>{
  $("#nameInput").value=state.childName; $("#pinInput").value=state.pin; $("#parentDialog").showModal();
};
$("#saveParentBtn").onclick=(e)=>{
  e.preventDefault();
  const name=$("#nameInput").value.trim(), pin=$("#pinInput").value.trim();
  if(name) state.childName=name;
  if(/^\d{4}$/.test(pin)) state.pin=pin;
  save(); $("#parentDialog").close(); toast("Parent settings saved");
};
$("#resetBtn").onclick=()=>{
  if(confirm("Reset all ChoreQuest data?")){
    state=JSON.parse(JSON.stringify(defaultState)); save(); $("#parentDialog").close(); toast("App reset");
  }
};
$("#addChoreBtn").onclick=()=>$("#addChoreDialog").showModal();
$("#saveChoreBtn").onclick=(e)=>{
  e.preventDefault();
  const title=$("#choreTitleInput").value.trim();
  const points=Math.max(1,Number($("#chorePointsInput").value)||10);
  if(!title){toast("Enter a chore name");return}
  state.chores.push({id:Date.now(),title,points,icon:"⭐",done:false});
  state.activity.unshift(`Added chore "${title}"`);
  $("#choreTitleInput").value="";
  save(); $("#addChoreDialog").close(); toast("Chore added");
};

if("serviceWorker" in navigator){ window.addEventListener("load",()=>navigator.serviceWorker.register("./service-worker.js")); }
render();
